# Farm for the demo: Kharipati / Sudal drone map (Bhaktapur)

**Place:** Kharipati / Sudal, north-east of Bhaktapur, Bhaktapur District, Bagmati Province, Nepal.

**What it is:** one real farm field cut out of an open drone map: "Kharipati/Sudal Imagery" by
**Rabi Shrestha** on OpenAerialMap (5 May 2026, DJI Mavic 2 Pro, 1.7 cm per pixel, CC-BY 4.0).
Its coordinates come from the drone map's own GeoTIFF (WGS 84 / UTM zone 45N).

**Inside the current NASA data box:** yes. The whole drone map is inside `demo.yaml`'s fetch box
`[85.379227, 27.625034, 85.480773, 27.714966]`, so **no new download is needed**.

## Files

| File | What it is |
| --- | --- |
| `one_farm_clean.jpg` | The farm alone, nothing drawn on it: for the "Is this your farm?" screen |
| `one_farm_13_patches.png` | The same farm split into **13 patches** of about 10 m × 10 m |
| `drone_map_with_farm.jpg` | The whole drone map, with the chosen farm outlined in red |
| `farm_coordinates.json` | Every coordinate below, ready for code |

## Key numbers

- **Field centre:** `27.686299, 85.463624`
- **Area:** about **1,089 m²** (about 2.1 ropani / 3.2 kattha), about 39 m × 32 m. Traced by eye
  along the field's bunds, so about ±5–10 %
- **Clean picture's corners:** south-west `27.686092, 85.463323`, north-east `27.686525, 85.463898`
  (in `site/data/basemap` format: `[[27.686092, 85.463323], [27.686525, 85.463898]]`)
- **Field outline:** 18 points, `[lon, lat]`, in `farm_coordinates.json` (`field_outline_lonlat`),
  the same format as the `polygon` in `config/fields/*.yaml`

## The 13 patches (where the robot tests)

A 10 m × 10 m grid, shifted to the position that gives the most whole patches for this field. Edge
pieces smaller than 50 m² are joined to a touching patch, so the whole field is covered. Numbered
from the south-west, row by row, west to east. Each point is the centre of that patch's own area.

| Patch | Centre (lat, lon) | Area |
| --- | --- | --- |
| p1 | 27.686194, 85.463524 | 81 m² |
| p2 | 27.686189, 85.463658 | 59 m² |
| p3 | 27.686191, 85.463760 | 59 m² |
| p4 | 27.686256, 85.463462 | 84 m² |
| p5 | 27.686259, 85.463555 | 100 m² |
| p6 | 27.686260, 85.463657 | 100 m² |
| p7 | 27.686261, 85.463758 | 100 m² |
| p8 | 27.686344, 85.463474 | 56 m² |
| p9 | 27.686349, 85.463554 | 99 m² |
| p10 | 27.686351, 85.463655 | 100 m² |
| p11 | 27.686351, 85.463753 | 93 m² |
| p12 | 27.686416, 85.463583 | 106 m² |
| p13 | 27.686424, 85.463751 | 52 m² |

## Important

1. **Credit:** *"Drone imagery: Rabi Shrestha, OpenAerialMap, CC-BY 4.0."*
2. **Probing time:** with the original robot code each patch takes about 1 minute, so 13 patches take
   about 13 minutes plus moving between them.
3. **Honesty:** this is a real drone survey (May 2026) standing in for our future drone photo. We have
   no farmer's answers for this field, so its crops and history are still unknown (the crop looked
   ripe and golden on 5 May).
4. **NASA data:** the field is about 2.2 km from the old placeholder field, inside the same box. HLS and
   NASADEM (30 m) see roughly this field itself (about 1 square); rain, weather, soil wetness and
   groundwater come from much bigger squares that include it (the same squares as before).
