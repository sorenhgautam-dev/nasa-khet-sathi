# Farm for the demo: Dhulikhel drone map

**Place:** Dhulikhel Municipality, Kavrepalanchok District, Bagmati Province, Nepal
(beside the Land Management Training Centre).

**What it is:** one real farm field cut out of an open drone map (OpenAerialMap, 8 Sep 2023,
DJI Mavic Pro, 12.7 cm per pixel). Its coordinates come from the drone map's own GeoTIFF
(WGS 84 / UTM zone 45N) and were checked by hand in Google Earth.

## Files

| File | What it is |
| --- | --- |
| `one_farm_clean.jpg` | The farm alone, nothing drawn on it: for the "Is this your farm?" screen |
| `one_farm_14_patches.png` | The same farm split into **14 patches** of about 10 m × 10 m |
| `drone_map_with_farm.jpg` | The whole drone map, with the chosen farm outlined in red |
| `farm_coordinates.json` | Every coordinate below, ready for code |

## Key numbers

- **Field centre:** `27.617935, 85.541910`
- **Area:** about **1,369 m²** (about 2.7 ropani / 4 kattha), about 56 m × 31 m. Traced by eye, so
  about ±5–10 %
- **Clean picture's corners:** north-west `27.618124, 85.541568`, south-east `27.617742, 85.542265`
  (in `site/data/basemap` format: `[[27.617742, 85.541568], [27.618124, 85.542265]]`)
- **Field outline:** 14 points, `[lon, lat]`, in `farm_coordinates.json` (`field_outline_lonlat`),
  the same format as the `polygon` in `config/fields/*.yaml`
- **Suggested 5 km data box** (like `demo.yaml`'s `fetch_box`):
  `[85.491219, 27.572717, 85.592601, 27.663154]`

## The 14 patches (where the robot tests)

A 10 m × 10 m grid centred on the field. Edge pieces smaller than 50 m² are joined to the nearest
patch, so the whole field is covered. Numbered from the south-west, row by row, west to east. Each
point is the centre of that patch's own area.

| Patch | Centre (lat, lon) | Area |
| --- | --- | --- |
| p1 | 27.617818, 85.541759 | 62 m² |
| p2 | 27.617890, 85.541686 | 56 m² |
| p3 | 27.617886, 85.541765 | 100 m² |
| p4 | 27.617865, 85.541865 | 150 m² |
| p5 | 27.617873, 85.541966 | 136 m² |
| p6 | 27.617886, 85.542066 | 107 m² |
| p7 | 27.617904, 85.542155 | 54 m² |
| p8 | 27.617976, 85.541678 | 74 m² |
| p9 | 27.617989, 85.541765 | 126 m² |
| p10 | 27.617997, 85.541865 | 141 m² |
| p11 | 27.617979, 85.541966 | 100 m² |
| p12 | 27.617999, 85.542066 | 142 m² |
| p13 | 27.617983, 85.542148 | 69 m² |
| p14 | 27.618047, 85.541966 | 53 m² |

## Important

1. **It is outside the current Bhaktapur data box** (6.1 km east, 0.7 km south of it). Every NASA
   dataset the app uses covers it, but the area's data has to be downloaded for the new box.
2. **Probing time:** with the original robot code, each patch takes about 1 minute, so 14 patches
   take about 14 minutes plus moving between them.
3. **Licence:** OpenAerialMap imagery is CC-BY 4.0. Look up the **provider's name** on the image's
   OpenAerialMap page and credit it: *"Drone imagery: [provider], OpenAerialMap, CC-BY 4.0."*
4. **Honesty:** this is a real drone survey from 2023 standing in for our future drone photo, and
   there are no farmer's answers for this field yet, so its crops and history are still unknown.
5. **Fine vs coarse data:** HLS and NASADEM (30 m) see roughly this farm itself (about 1–2 squares);
   rain, weather, soil wetness and groundwater come from much bigger squares that include the farm.
